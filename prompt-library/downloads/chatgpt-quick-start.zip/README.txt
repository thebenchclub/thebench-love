ChatGPT Quick Start
3 prompts for anyone new to ChatGPT — brainstorm, draft, and research, done right

Downloaded from The Bench Club free prompt library.
Use these prompts in ChatGPT, Claude, or your preferred AI workspace. Review factual, legal, compliance-sensitive, and customer-facing details before publishing.
